import logo from './logo.svg';
import './App.css';
import { Registeration } from './components/registration';

function App() {
  return (
    <div>
      <Registeration></Registeration>
    </div>
  );
}

export default App;
