
import './App.css';
import ColorChanger from './components/color-changer';


function App() {
  return (
    <div className="App">
      <ColorChanger></ColorChanger>
    </div>
  );
}

export default App;
